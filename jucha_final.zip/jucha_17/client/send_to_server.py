import requests

def send_plate_text(text):
    """
    인식된 번호판 텍스트를 서버로 HTTP POST 전송
    서버가 없거나 오류 발생 시 시뮬레이션 메시지 출력
    """
    url = 'http://192.168.118.14:5000/api/parking'  # 서버 주소(필요시 변경)
    try:
        response = requests.post(url, json={'plate': text})
        if response.status_code == 200:
            print("[Server] Plate sent successfully.")
        else:
            print(f"[Server] Failed to send. Status code: {response.status_code}")
    except Exception as e:
        print(f"[Server] No server available. Simulated send: '{text}'") 