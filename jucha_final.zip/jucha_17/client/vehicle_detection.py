# 차량을 감지하고, 충분히 크면 확대하여 이미지로 저장하는 모듈

import cv2
from ultralytics import YOLO
from datetime import datetime
import os

# YOLOv8 경량 모델 로드
model = YOLO('yolov8n.pt')  # 작은 경량 모델 사용
# 차량 이미지 저장 폴더 생성
os.makedirs('images', exist_ok=True)

def detect_vehicle(frame):
    """
    입력 프레임에서 차량을 감지하고, 일정 크기 이상이면 이미지를 저장
    - annotated_frame: 차량 박스가 그려진 프레임
    - captured: 차량이 감지되어 저장되었는지 여부
    - img_path: 저장된 이미지 경로(없으면 빈 문자열)
    """
    results = model(frame)
    boxes = results[0].boxes
    annotated_frame = frame.copy()

    captured = False
    img_path = ""

    for box in boxes:
        cls = int(box.cls[0])  # 클래스 인덱스
        label = model.names[cls]  # 클래스 이름
        if label not in ['car', 'truck', 'bus']:
            continue  # 차량이 아니면 무시

        x1, y1, x2, y2 = map(int, box.xyxy[0])  # 바운딩 박스 좌표
        w, h = x2 - x1, y2 - y1
        area_ratio = (w * h) / (frame.shape[0] * frame.shape[1]) * 100  # 프레임 대비 박스 비율(%)

        # 박스와 라벨을 프레임에 그림
        cv2.rectangle(annotated_frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(annotated_frame, f"{label} {area_ratio:.2f}%", (x1, y1 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        # 충분히 큰 차량만 저장
        if area_ratio > 20:
            print(f"[Detection] {label} detected, large enough: {area_ratio:.2f}%")
            cropped = frame[y1:y2, x1:x2]  # 차량 영역만 잘라냄
            enlarged = cv2.resize(cropped, None, fx=2.5, fy=2.5, interpolation=cv2.INTER_LINEAR)  # 확대
            img_path = f"images/vehicle.jpg"
            cv2.imwrite(img_path, enlarged)  # 이미지 저장
            captured = True
            break  # 첫 번째 큰 차량만 처리

    return annotated_frame, captured, img_path
