#!/bin/bash

# 클라이언트 환경 구축 스크립트 (가상환경 활성화 후 실행)

# 파이썬 패키지 설치
echo "[Setup] Installing Python packages..."
pip install opencv-python numpy matplotlib pytesseract requests ultralytics

# OCR을 위한 시스템 패키지 설치
# (Tesseract는 번호판 문자 인식에 필요)
echo "[Setup] Installing system package for OCR..."
sudo apt-get update
sudo apt-get install -y tesseract-ocr

echo "[Setup] Setup complete." 