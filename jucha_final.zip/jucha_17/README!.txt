client - 카메라 모듈 연결된 라즈베리파이 5
server - 서버역할 할 라즈베리파이 4 
둘다 setup.sh 실행 후 main.py/server.py실행하시면 됩니다!!!
https://github.com/standup2525/juchajang 깃허브 링크입니다
아래는 자세한 설명입니다

라즈베리파이 5 (카메라, 번호판 인식후 json형식으로 차량번호를 서버에 전송)
vehicle_detection.py - 비디오 프레임에서 차량을 감지합니다.
setup.sh - 라이브러리 및 모듈 등을 설치합니다.
main.py - 주요 애플리케이션 로직.
send to server.py - 데이터를 서버로 전송합니다.
plate_reader.py - 이미지에서 번호판을 읽습니다.

라즈베리파이 4 (서버, 웹페이지 구현)
server.py - Flask 기반 서버 코드. 입출차 기록 처리, 요금 계산, 웹 UI 제공을 담당합니다.
templates/index.html - 전체 주차 상태 확인 페이지. 테이블 형식으로 기록을 시각화합니다.
templates/kiosk.html - 차량 번호 입력을 통해 주차 요금을 조회하는 키오스크 페이지입니다.
parking.db - 차량 입출차 정보가 저장되는 SQLite 데이터베이스 파일입니다.