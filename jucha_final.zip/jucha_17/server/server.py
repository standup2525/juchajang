from flask import Flask, request, jsonify, render_template
import sqlite3
from datetime import datetime, timedelta
import os
from time import time

app = Flask(__name__)

# 최근 요청 시간 저장용 딕셔너리 (같은 차량이 너무 자주 요청 안 오게 하려고)
recent_requests = {}

# 데이터베이스 만들기
def init_db():
    conn = sqlite3.connect('parking.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS parking_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            plate_number TEXT NOT NULL,
            entry_time TEXT NOT NULL,
            exit_time TEXT,
            status TEXT NOT NULL,
            fee INTEGER DEFAULT 0
        )
    ''')
    conn.commit()
    conn.close()

# 한 달 넘은 오래된 기록은 정리해주는 함수 
def cleanup_old_records():
    conn = sqlite3.connect('parking.db')
    c = conn.cursor()
    one_month_ago = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d %H:%M:%S')
    c.execute('DELETE FROM parking_records WHERE entry_time < ?', (one_month_ago,))
    conn.commit()
    conn.close()

# 키오스크에서 차량번호 입력받고 조회하는 화면 (plate 입력받아서 조회)
@app.route('/kiosk', methods=['GET', 'POST'])
def kiosk():
    result = None
    if request.method == 'POST':
        plate = request.form.get('plate')
        conn = sqlite3.connect('parking.db')
        c = conn.cursor()
        # 최신 기록 하나만 가져오기 (최근 방문기록 보여주려고)
        c.execute('''
            SELECT plate_number, entry_time, exit_time, status, fee
            FROM parking_records
            WHERE plate_number = ?
            ORDER BY entry_time DESC
            LIMIT 1
        ''', (plate,))
        result = c.fetchone()
        conn.close()
    return render_template('kiosk.html', result=result)

# 차량이 입차/출차할 때 호출되는 API (카메라 인식 결과가 이쪽으로 옴)
@app.route('/plate', methods=['POST'])
def handle_parking():
    data = request.json
    plate_number = data.get('plate')

    if not plate_number:
        return jsonify({'error': 'Missing required data'}), 400

    now = time()  # 지금 시간 (초 단위)

    # 너무 자주 들어오면 무시 (5초 이내 중복 방지)
    last_time = recent_requests.get(plate_number)
    if last_time and now - last_time < 5:
        return jsonify({'status': 'ignored', 'message': 'Too frequent request'}), 200

    recent_requests[plate_number] = now  # 이번 요청 시간 기록

    conn = sqlite3.connect('parking.db')
    c = conn.cursor()

    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # 입출차 시간 기록용

    # 현재 이 차량이 이미 주차 중인지 확인
    c.execute('SELECT id, status FROM parking_records WHERE plate_number = ? AND status = "parked"', (plate_number,))
    existing = c.fetchone()

    if existing:
        # 이미 주차 중이었으면 이제 출차 처리
        c.execute('UPDATE parking_records SET exit_time = ?, status = "exited" WHERE id = ?', (timestamp, existing[0]))
        message = f"Vehicle {plate_number} has exited"
    else:
        # 없으면 새로 입차 기록 추가
        c.execute('INSERT INTO parking_records (plate_number, entry_time, status) VALUES (?, ?, "parked")', (plate_number, timestamp))
        message = f"Vehicle {plate_number} has entered"

    conn.commit()
    conn.close()

    return jsonify({'status': 'success', 'message': message}), 200

# 홈페이지 접속 시 주차 현황 보여주는 메인 페이지
@app.route('/')
def index():
    conn = sqlite3.connect('parking.db')
    c = conn.cursor()

    # 모든 차량 정보 조회 (최근 100개만 id값 사용해서 같은 차량 중복되어도 각각 다르게 구분할 수 있음 -> 가장 큰 id값은 가장 최신이라는 뜻)
    c.execute('''
        SELECT id, plate_number, entry_time, exit_time, status, fee
        FROM parking_records
        ORDER BY entry_time DESC
        LIMIT 100
    ''')
    records = c.fetchall()

    # 출차된 차량의 요금 계산
    for record in records:
        if record[3] == "exited" and record[1] and record[2]:
            try:
                entry_time = datetime.strptime(record[1], '%Y-%m-%d %H:%M:%S')
                exit_time = datetime.strptime(record[2], '%Y-%m-%d %H:%M:%S')
                duration = (exit_time - entry_time).seconds # 초 단위로 계산
                fee = duration * 100 if duration > 0 else 0  # 초당 100원

                # 요금 업데이트
                c.execute('UPDATE parking_records SET fee = ? WHERE id = ?', (fee, record[0]))
                conn.commit()
            except Exception as e:
                print(f"Error calculating fee for {record[0]}: {e}")

    # 다시 데이터 가져와서 화면에 뿌림(id 제외)
    c.execute('''
        SELECT plate_number, entry_time, exit_time, status, fee
        FROM parking_records
        ORDER BY entry_time DESC
        LIMIT 100
    ''')
    display_records = c.fetchall()
    conn.close()

    return render_template('index.html', records=display_records)




# templates 폴더 없으면 만들어두기 (HTML 파일이 여기에 들어감)
os.makedirs('templates', exist_ok=True)

# index.html 파일 생성 (관리자 페이지 – 전체 입출차 목록 보여줌)
with open('templates/index.html', 'w') as f:
    f.write('''
<!DOCTYPE html>
<html>
<head>
    <title>Parking System</title>

    <-- 키오스크 버튼 (오른쪽 상단에 있음) -->
    <a href="/kiosk"><button>kiosk</button></a>

    <style>
        /* 기본 스타일: 배경색, 폰트 등 */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f0f0f0;
        }

        h1 {
            color: #333;
            text-align: center;
        }

        /* 표 스타일 */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: white;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        .status-parked {
            color: #4CAF50;
            font-weight: bold;
        }

        .status-exited {
            color: #666;
        }
    </style>
</head>
<body>
    <h1>Parking System Status</h1>

    <-- 차량 목록 테이블 -->
    <table>
        <tr>
            <th>Plate Number</th>
            <th>Entry Time</th>
            <th>Exit Time</th>
            <th>Status</th>
            <th>Fee</th>
        </tr>

        <-- 파이썬에서 전달받은 데이터(records)를 테이블에 하나씩 보여줌 -->
        {% for record in records %}
        <tr>
            <td>{{ record[0] }}</td>
            <td>{{ record[1] }}</td>
            <td>{{ record[2] if record[2] else '-' }}</td>
            <td class="status-{{ record[3] }}">{{ record[3] }}</td>
            <td>{{ record[4] if record[4] else '0' }}won</td>
        </tr>
        {% endfor %}
    </table>

    <-- 아래쪽에도 키오스크 버튼 하나 더 -->
    <a href="/kiosk"><button>kiosk</button></a>
</body>
</html>
    ''')

# ▶ kiosk.html 파일 생성 (사용자가 차량번호 넣고 요금 조회하는 화면)
os.makedirs('templates', exist_ok=True)
with open('templates/kiosk.html', 'w') as f:
    f.write('''
<!DOCTYPE html>
<html>
<head>
    <title>Fee Inquiry Kiosk</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f0f0f0;
            padding: 40px;
            text-align: center;
        }

        input[type="text"] {
            padding: 10px;
            font-size: 16px;
            width: 250px;
        }

        button {
            padding: 10px 20px;
            font-size: 16px;
        }

        .result-box {
            margin-top: 30px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            display: inline-block;
            box-shadow: 0 0 5px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <h1>Parking Fee Inquiry Kiosk</h1>

    <-- 사용자 입력 폼 (차량번호 넣고 조회 누름) -->
    <form method="post">
        <input type="text" name="plate" placeholder="Enter plate number" required />
        <button type="submit">Check</button>
    </form>

    <-- 조회 결과가 있을 때 출력 -->
    {% if result %}
    <div class="result-box">
        <p><strong>Plate Number:</strong> {{ result[0] }}</p>
        <p><strong>Entry Time:</strong> {{ result[1] }}</p>
        <p><strong>Exit Time:</strong> {{ result[2] if result[2] else 'Currently Parked' }}</p>
        <p><strong>Status:</strong> {{ result[3] }}</p>
        <p><strong>Fee:</strong> {{ result[4] }} won</p>
    </div>

    <-- 결과는 없는데 입력은 있었을 경우 -->
    {% elif result is not none %}
    <p style="color:red;">? No record found for the entered plate number.</p>
    {% endif %}
</body>
</html>
    ''')

# 앱 실행 시작! (서버 시작점)
if __name__ == '__main__':
    init_db()  # 데이터베이스 준비
    cleanup_old_records()  # 오래된 데이터 정리
    app.run(host='0.0.0.0', port=5000)  # 외부 접속 가능하도록 서버 실행
